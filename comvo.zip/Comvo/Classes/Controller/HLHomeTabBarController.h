//
//  HLHomeTabBarController.h
//  Comvo
//
//  Created by Akio Morita on 12/23/14.
//  Copyright (c) 2014 DeMing Yu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HLHomeTabBarController : UITabBarController

@end
