//
//  HLTokboxClient.m
//  SmartFleet
//
//  Created by Administrator on 12/3/14.
//  Copyright (c) 2014 Mobsafety. All rights reserved.
//

#import "HLTokboxClient.h"
#import <OpenTok/OpenTok.h>
#import "MSPublisher.h"
#import "MSSubscriber.h"

@interface HLTokboxClient() <OTSessionDelegate, OTPublisherKitDelegate, OTSubscriberKitDelegate>
{
    void (^sessionCloseCompletion)(BOOL success, NSError *error);
    void (^sessionConnectCompletion)(BOOL success, NSError *error);
    void (^messageReceivedBlock)(NSString *message, NSString *type);
    void (^recipientJoinedBlock)();
    void (^recipientDisconnectedBlock)();
    void (^publishCompletion)(BOOL success, NSError *error, UIView *view);
    void (^subscribeCompletion)(BOOL success, NSError *error, UIView *view);
    void (^subscriberConnectedBlock)(UIView *view);
    void (^subscriberDisconnectedBlock)();
}

@property (nonatomic, strong) OTSession *session;
@property (nonatomic, strong) MSPublisher *publisher;
@property (nonatomic, strong) MSSubscriber *subscriber;
@property (nonatomic, strong) OTStream *stream;
@property (nonatomic, strong) NSMutableArray *connections;
@property (nonatomic) BOOL sessionCreated;

@end

@implementation HLTokboxClient

+ (HLTokboxClient *)sharedClient
{
    static HLTokboxClient *sharedClient = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        sharedClient = [[HLTokboxClient alloc] init];
    });
    
    return sharedClient;
}

- (id)init
{
    self = [super init];
    
    self.session = nil;
    sessionCloseCompletion = nil;
    sessionConnectCompletion  = nil;
    messageReceivedBlock = nil;
    recipientJoinedBlock = nil;
    publishCompletion = nil;
    subscribeCompletion = nil;
    recipientDisconnectedBlock = nil;
    subscriberConnectedBlock = nil;
    subscriberDisconnectedBlock = nil;
    self.connections = [[NSMutableArray alloc] init];
    self.sessionCreated = NO;
    
    return self;
}

#pragma mark - Public Interfaces

- (void)connectWithAPIKey:(NSString *)apiKey
                sessionID:(NSString *)sessionId
                    token:(NSString *)token
               completion:(void (^)(BOOL success, NSError *error))completion
          messageReceived:(void (^)(NSString *, NSString *type))messageReceived
          recipientJoined:(void (^)())recipientJoined
    recipientDisconnected:(void (^)())recipientDisconnected

{
    if ([self hasSession]) {
        __weak typeof(self) weakSelf = self;
        [self closeSessionWithCompletion:^(BOOL success, NSError *error) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (success) {
                [strongSelf internalConnectWithAPIKey:apiKey sessionID:sessionId token:token completion:completion];
            }
            else {
                if (completion)
                    completion(NO, error);
            }
        }];
    } else {
        [self internalConnectWithAPIKey:apiKey sessionID:sessionId token:token completion:completion];
    }
    messageReceivedBlock = [messageReceived copy];
    recipientJoinedBlock = [recipientJoined copy];
    recipientDisconnectedBlock = [recipientDisconnected copy];
}

- (void)internalConnectWithAPIKey:(NSString *)apiKey
                        sessionID:(NSString *)sessionId
                            token:(NSString *)token
                       completion:(void (^)(BOOL success, NSError *error))completion
{
    self.session = [[OTSession alloc] initWithApiKey:apiKey
                                           sessionId:sessionId
                                            delegate:self];
    
    OTError *error = nil;
    
    sessionConnectCompletion = [completion copy];
    [_session connectWithToken:token error:&error];
    if (error) {
        sessionConnectCompletion = nil;
        completion(NO, error);
        return;
    }
}

#pragma mark - Session Management

- (BOOL)hasSession
{
    return self.session != nil;
}

- (BOOL)isSessionCreated
{
    return self.sessionCreated;
}

- (BOOL)hasRecipient
{
    return [self.connections count] >= 1;
}

- (void)closeSessionWithCompletion:(void (^)(BOOL success, NSError *error))completion
{
    if (self.session) {
        OTError *error = nil;
        if (completion)
            sessionCloseCompletion = [completion copy];
        [self.session disconnect:&error];
        
        if (error) {
            sessionCloseCompletion = nil;
            if (completion)
                completion(NO, error);
        } else {
            if (completion)
                completion(YES, nil);
        }
        self.session = nil;
        self.connections = nil;
    }
}

#pragma mark - Content Management

- (void)sendMessage:(NSString *)message
{
    if ([self hasSession]) {
        OTError *error;
        [self.session signalWithType:@"in" string:message connection:nil error:&error];
        NSLog(@"%@", error);
    }
}

- (void)publishStreamWithCompletion:(void (^)(BOOL, NSError *, UIView *))completion
                subscriberConnected:(void (^)(UIView *))subscriberConnected
             subscriberDisconnected:(void (^)())subscriberDisconnected

{
    if ([self hasSession]) {
        self.publisher = [[MSPublisher alloc] initWithDelegate:self];
        OTError *error;
        [self.session publish:self.publisher error:&error];
        if (error)
            completion(NO, error, nil);
        else
            publishCompletion = [completion copy];
        if (subscriberConnected)
            subscriberConnectedBlock = [subscriberConnected copy];
        if (subscriberDisconnected)
            subscriberDisconnectedBlock = [subscriberDisconnected copy];
    }
}

- (void)unPublishStreamWithCompletion:(void (^)(BOOL, NSError *))completion
{
    if ([self hasSession]) {
        OTError *error;
        [self.session unpublish:self.publisher error:&error];
        if (error)
            completion(NO, error);
        else
            completion(YES, nil);
    }
}

- (void)subscribeStreamWithCompletion:(void (^)(BOOL, NSError *, UIView *))completion
{
    if ([self hasSession]) {
        self.subscriber = [[MSSubscriber alloc] initWithStream:self.stream delegate:self];
        OTError *error;
        [self.session subscribe:self.subscriber error:&error];
        if (error)
            completion(NO, error, nil);
        else
            subscribeCompletion = [completion copy];
    }
}

#pragma mark - OTSession delegate callbacks

- (void)sessionDidConnect:(OTSession*)session
{
    NSLog(@"sessionDidConnect (%@)", session.sessionId);
    sessionConnectCompletion(YES, nil);
    self.sessionCreated = YES;
}

- (void)sessionDidDisconnect:(OTSession*)session
{
    if ([session.sessionId isEqualToString:self.session.sessionId]) {
        NSString* alertMessage = [NSString stringWithFormat:@"Session disconnected: (%@)", session.sessionId];
        NSLog(@"sessionDidDisconnect (%@)", alertMessage);
        
        self.session = nil;
        self.publisher = nil;
        self.subscriber = nil;
        self.stream = nil;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (sessionCloseCompletion)
                sessionCloseCompletion(YES, nil);
        });
    }
}

- (void)session:(OTSession*)session didFailWithError:(OTError*)error
{
    if ([session.sessionId isEqualToString:self.session.sessionId]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (sessionConnectCompletion)
                sessionConnectCompletion(NO, error);
        });
    }
}

- (void)session:(OTSession *)session streamCreated:(OTStream *)stream
{
    if ([session.sessionId isEqualToString:self.session.sessionId] && ![stream.connection.connectionId isEqualToString:self.session.connection.connectionId]) {
        self.stream = stream;
        if (self.publisher == nil) {
//            [[NSNotificationCenter defaultCenter] postNotificationName:NotVideo object:nil];
        } else {
            [self subscribeStreamWithCompletion:^(BOOL success, NSError *error, UIView *view) {
                if (success && subscriberConnectedBlock)
                    subscriberConnectedBlock(view);
            }];
        }
    }
}

- (void)session:(OTSession *)session streamDestroyed:(OTStream *)stream
{
    if ([session.sessionId isEqualToString:self.session.sessionId] && ![self.stream.connection.connectionId isEqualToString:self.session.connection.connectionId]) {
        OTError *error;
        [self.session unsubscribe:self.subscriber error:&error];
        if (error == nil) {
            subscriberDisconnectedBlock();
        }
    }
}

- (void)session:(OTSession *)session receivedSignalType:(NSString *)type fromConnection:(OTConnection *)connection withString:(NSString *)string
{
    if ([session.sessionId isEqualToString:self.session.sessionId] && ![connection.connectionId isEqualToString:self.session.connection.connectionId])
        messageReceivedBlock(string, type);
}

- (void)session:(OTSession *)session connectionCreated:(OTConnection *)connection
{
    if ([session.sessionId isEqualToString:self.session.sessionId] && ![connection.connectionId isEqualToString:self.session.connection.connectionId]) {
        if (recipientJoinedBlock != nil) {
            recipientJoinedBlock();
        }
        [self.connections addObject:connection];
    }
}

- (void)session:(OTSession *)session connectionDestroyed:(OTConnection *)connection
{
    if ([session.sessionId isEqualToString:self.session.sessionId] && ![connection.connectionId isEqualToString:self.session.connection.connectionId]) {
        [self.connections removeObject:connection];
        if ([self.connections count] == 0) {
            if (recipientDisconnectedBlock != nil) {
                recipientDisconnectedBlock();
            }
            [self closeSessionWithCompletion:nil];
        }
    }
}

#pragma mark - OTPublisher Delegate Methods

- (void)publisher:(OTPublisherKit *)publisher streamCreated:(OTStream *)stream
{
    publishCompletion(YES, nil, self.publisher.view);
}

- (void)publisher:(OTPublisherKit *)publisher streamDestroyed:(OTStream *)stream
{
    publishCompletion(NO, nil, nil);
}

- (void)publisher:(OTPublisherKit *)publisher didFailWithError:(OTError *)error
{
    publishCompletion(NO, error, nil);
}

#pragma mark - OTSubscriber Delegate Methods

- (void)subscriberDidConnectToStream:(OTSubscriberKit *)subscriber
{
    subscribeCompletion(YES, nil, self.subscriber.view);
}

- (void)subscriber:(OTSubscriberKit *)subscriber didFailWithError:(OTError *)error
{
    subscribeCompletion(NO, error, nil);
}

@end
