//
//  HLTokboxClient.h
//  Comvo
//
//  Created by Administrator on 12/3/14.
//  Copyright (c) 2014 Mobsafety. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenTok/OpenTok.h>

@interface HLTokboxClient : NSObject

+ (HLTokboxClient *)sharedClient;

- (void)connectWithAPIKey:(NSString *)apiKey
                sessionID:(NSString *)sessionId
                    token:(NSString *)token
               completion:(void (^)(BOOL success, NSError *error))completion
          messageReceived:(void (^)(NSString *message, NSString *type))messageReceived
          recipientJoined:(void (^)())recipientJoined
    recipientDisconnected:(void (^)())recipientDisconnected;

- (BOOL)hasSession;
- (BOOL)isSessionCreated;
- (BOOL)hasRecipient;
- (void)closeSessionWithCompletion:(void (^)(BOOL success, NSError *error))completion;
- (void)sendMessage:(NSString *)message;
- (void)publishStreamWithCompletion:(void (^)(BOOL success, NSError *error, UIView *view))completion
                subscriberConnected:(void (^)(UIView *view))subscriberConnected
                subscriberDisconnected:(void (^)())subscriberDisconnected;
- (void)unPublishStreamWithCompletion:(void (^)(BOOL success, NSError *))completion;
- (void)subscribeStreamWithCompletion:(void (^)(BOOL success, NSError *error, UIView *view))completion;

@end
