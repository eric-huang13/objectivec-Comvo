//
//  TMSDKUserAgent.h
//  TMTumblrSDK
//
//  Created by Bryan Irace on 12/17/14.
//  Copyright (c) 2014 Tumblr. All rights reserved.
//

@import Foundation;

@interface TMSDKUserAgent : NSObject

+ (NSString *)userAgentHeaderString;

@end
