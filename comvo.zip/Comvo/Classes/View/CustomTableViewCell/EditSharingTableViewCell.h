//
//  EditSharingTableViewCell.h
//  Comvo
//
//  Created by Max Brian on 02/10/15.
//  Copyright (c) 2015 DeMing Yu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditSharingTableViewCell : UITableViewCell

@end
