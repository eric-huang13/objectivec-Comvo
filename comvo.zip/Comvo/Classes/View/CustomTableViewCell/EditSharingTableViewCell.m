//
//  EditSharingTableViewCell.m
//  Comvo
//
//  Created by Max Brian on 02/10/15.
//  Copyright (c) 2015 DeMing Yu. All rights reserved.
//

#import "EditSharingTableViewCell.h"

@implementation EditSharingTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
