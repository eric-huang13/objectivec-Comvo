//
//  HLHomeViewController.h
//  Comvo
//
//  Created by Max Brian on 05/11/15.
//  Copyright (c) 2015 DeMing Yu. All rights reserved.
//

#import "RDVTabBarController.h"
#import "RDVTabBarItem.h"
#import "RDVTabBarController.h"

@interface HLHomeViewController : RDVTabBarController <RDVTabBarControllerDelegate>

@end
